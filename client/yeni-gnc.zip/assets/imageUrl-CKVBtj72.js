const p="https://papucgnc-production-01f6.up.railway.app",s=t=>t?t.startsWith("http://")||t.startsWith("https://")?t:`${p}${t}`:"";export{s as g};
