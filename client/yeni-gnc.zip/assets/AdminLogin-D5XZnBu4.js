import{c as r,r as t,u,j as e}from"./index-B4wOv53s.js";import{S as f}from"./shield-check-H8QvLLP0.js";import{A as p}from"./alert-circle-BZpCAfWY.js";/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=r("EyeOff",[["path",{d:"M9.88 9.88a3 3 0 1 0 4.24 4.24",key:"1jxqfv"}],["path",{d:"M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68",key:"9wicm4"}],["path",{d:"M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61",key:"1jreej"}],["line",{x1:"2",x2:"22",y1:"2",y2:"22",key:"a6p6uj"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=r("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=r("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]),v=()=>{const[i,c]=t.useState(""),[a,d]=t.useState(!1),[n,l]=t.useState(""),[m,o]=t.useState(!1),x=u(),h=s=>{s.preventDefault(),i==="jwan1919"?(sessionStorage.setItem("adminAuth","true"),x("/adminjwan")):(l("Şifre hatalı!"),o(!0),setTimeout(()=>o(!1),600))};return e.jsxs("div",{className:"min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center p-4",children:[e.jsx("div",{className:"absolute inset-0 opacity-5",children:e.jsx("div",{className:"absolute inset-0",style:{backgroundImage:"radial-gradient(circle at 1px 1px, white 1px, transparent 0)",backgroundSize:"40px 40px"}})}),e.jsxs("div",{className:`relative w-full max-w-md ${m?"animate-shake":""}`,children:[e.jsxs("div",{className:"bg-white/10 backdrop-blur-xl rounded-3xl border border-white/10 shadow-2xl overflow-hidden",children:[e.jsxs("div",{className:"bg-gradient-to-r from-gray-800 to-gray-900 px-8 py-10 text-center",children:[e.jsx("div",{className:"w-20 h-20 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-5 backdrop-blur-sm border border-white/10",children:e.jsx(f,{className:"w-10 h-10 text-white"})}),e.jsx("h1",{className:"text-2xl font-black text-white tracking-tight",children:"Admin Panel"}),e.jsx("p",{className:"text-gray-400 text-sm mt-2",children:"Yönetim paneline erişmek için şifrenizi girin"})]}),e.jsx("div",{className:"px-8 py-8",children:e.jsxs("form",{onSubmit:h,className:"space-y-5",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-semibold text-gray-300 mb-2",children:[e.jsx(w,{className:"w-4 h-4 inline mr-2"}),"Şifre"]}),e.jsxs("div",{className:"relative",children:[e.jsx("input",{type:a?"text":"password",value:i,onChange:s=>{c(s.target.value),l("")},placeholder:"Şifrenizi girin...",className:"w-full px-5 py-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-white/20 transition-all text-sm",autoFocus:!0}),e.jsx("button",{type:"button",onClick:()=>d(!a),className:"absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors",children:a?e.jsx(y,{className:"w-5 h-5"}):e.jsx(g,{className:"w-5 h-5"})})]})]}),n&&e.jsxs("div",{className:"flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-red-400 text-sm animate-fadeIn",children:[e.jsx(p,{className:"w-4 h-4 flex-shrink-0"}),e.jsx("span",{children:n})]}),e.jsx("button",{type:"submit",className:"w-full bg-white text-gray-900 py-4 rounded-xl font-black text-sm tracking-wider hover:bg-gray-200 transition-all transform hover:scale-[1.02] active:scale-[0.98]",children:"GİRİŞ YAP"})]})})]}),e.jsx("p",{className:"text-center text-gray-600 text-xs mt-6",children:"Yetkisiz erişim girişimleri kayıt altına alınmaktadır."})]}),e.jsx("style",{children:`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-8px); }
          20%, 40%, 60%, 80% { transform: translateX(8px); }
        }
        .animate-shake {
          animation: shake 0.6s ease-in-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-5px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `})]})};export{v as default};
