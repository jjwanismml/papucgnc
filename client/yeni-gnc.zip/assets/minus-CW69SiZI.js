import{c as s}from"./index-Bis_MxYo.js";/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
