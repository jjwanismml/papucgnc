const p="https://papucgnc-production.up.railway.app",s=t=>t?t.startsWith("http://")||t.startsWith("https://")?t:`${p}${t}`:"";export{s as g};
